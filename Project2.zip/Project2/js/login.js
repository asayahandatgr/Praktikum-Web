// program yang akan dijalankan javascript

function login() {
    // Mengambil nilai username dan password dari form
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    let form = document.getElementById("loginForm"); // Redirect ke web berbeda

    // Menyimpan pasangan username dan password dalam objek
    var validLogins = {
        "Admin": "Admin123",
        "Siti Sa'diyah": "Admin456",
        "Nurlatifatussolihah": "Admin789",
        "Muhamad Rizki Fadilah": "Admin012",
        "Irdad Suryani": "Admin345"
    };

    // Memeriksa apakah username dan password sesuai dengan yang ditentukan
    if (validLogins.hasOwnProperty(username) && validLogins[username] === password) {
        alert("Login Berhasil");
        // form.setAttribute("action", "");  // Jika perlu mengubah action formulir
    } else {
        alert("Username atau Password yang anda masukkan salah");
    }
}


       
